package mypackage;



import java.io.InputStream;

import com.omt.epubreader.domain.Book;
import com.omt.epubreader.domain.Epub;

import net.rim.device.api.ui.Field;
import net.rim.device.api.ui.FieldChangeListener;
import net.rim.device.api.ui.component.ButtonField;
import net.rim.device.api.ui.component.Dialog;
import net.rim.device.api.ui.component.EditField;
import net.rim.device.api.ui.container.MainScreen;

/**
 * A class extending the MainScreen class, which provides default standard
 * behavior for BlackBerry GUI applications.
 */
public final class MyScreen extends MainScreen implements FieldChangeListener
{
    /**
     * Creates a new MyScreen object
     */
	ButtonField bf = new ButtonField("Start Reading");
	EditField ef = new EditField();
    public MyScreen()
    {        
        // Set the displayed title of the screen       
        setTitle("MyTitle");
        bf.setChangeListener(this);
        add(bf);
        add(ef);
        
    }
    public void fieldChanged(Field field, int context) {
    	if(field == bf)
    	{
    	 System.out.println("Bf :"+bf.getLabel());
    	 //Dialog.alert("Press Ok Button To Start Reading:"+ef.getText());
    	 Epub e = new Epub();
    	 InputStream in = this.getClass().getResourceAsStream("omte.epub"); 
    	 Book b = e.getBook(in);
    	 System.out.println("Omt Book Title:"+b.getTitle());
    	 System.out.println("Omt Book Chapter Data:"+b.getChaptersData());
    	 
    	
    	}
    }
    
}
