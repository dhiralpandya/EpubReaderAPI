package com.omt.epub.main;

import com.omt.epubreader.domain.Book;
import com.omt.epubreader.domain.Epub;

public class Main {
	public static void main(String args[])
	{
		Epub epub = new Epub();
		Book book = epub.getBook(Main.class.getResourceAsStream("omte.epub"));
		System.out.println("Book Title :"+book.getTitle());
	}
}
